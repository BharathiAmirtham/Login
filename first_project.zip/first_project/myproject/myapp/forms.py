from .models import MyModel
from django import forms

class MyModelForm(forms.ModelForm):
    class Meta:
        model = MyModel
        fields = ('username', 'password')
        