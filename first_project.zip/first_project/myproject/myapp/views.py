from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from .forms import MyModelForm
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User

def login_view(request):
    if request.method == 'POST':
        username=request.POST.get('username',None)
        password=request.POST.get('password',None)
        print(username,"username")
        print(password,"password")


        user = authenticate(request, username=username, password=password)
        #u = User.objects.get(username__exact=username)
        #print(user.password,"password3333")
        #print(user1.username,"user check")
        #print(user1.password,"user pass")
        if user is not None:
            #print("not login")
            return redirect('main.html') 
        else:
            return render(request, 'home.html', {'error': 'Invalid credentials.'})
    else:
        return render(request, 'login.html')

def logout_view(request):
    logout(request)
    if request.method == 'POST':
        user = authenticate(request, username=username, password=password)
        return redirect('login') 

    else:
        return redirect('logout')
 


def signup_view(request):
    
    if request.method == 'POST':

        print("post")
        username=request.POST.get('username',None)
        email=request.POST.get('email',None)
        password=request.POST.get('password',None)
        #user = User.objects.create(username=username, email=email, password=make_password(password))
        #user.save()
        return render(request, 'home.html')
    else:
        print("get")
        return render(request, 'register.html')

def home(request):  
    return render(request, 'home.html')

def main(request):  
    return render(request, 'main.html')








