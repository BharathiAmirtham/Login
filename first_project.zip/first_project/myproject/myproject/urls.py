from django.contrib import admin
from django.urls import path, include
from myapp import views
from myapp import templates

urlpatterns = [
    path("admin/", admin.site.urls),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup_view/', views.signup_view, name='signup'),
    path('home/', views.home, name='home'),
    path('main/', views.main, name='main'),

    
    
]
